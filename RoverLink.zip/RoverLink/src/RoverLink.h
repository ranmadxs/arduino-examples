#ifndef RoverLink_h
#define RoverLink_h

#define ROVER_TYPE_2WD					"2WD"

#define ROVER_BODY_MOVE_TYPE_LEFT		"LEFT"
#define ROVER_BODY_MOVE_TYPE_RIGHT		"RIGHT"
#define ROVER_BODY_MOVE_TYPE_FORWARD	"FORWARD"
#define ROVER_BODY_MOVE_TYPE_BACK		"BACK"

class RoverLink
{
public:
  RoverLink();
private:
};